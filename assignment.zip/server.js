//create a basic server
const express = require('express')
// calling express function
const app = express()
// create a user variable array
const users = [
{id:1,name: 'user 1'},
{id:2,name: 'user 2'},
{id:3,name: 'user 3'},
{id:4,name: 'user 4'},
{id:5,name: 'user 5'},
{id:6,name: 'user 6'},
{id:7,name: 'user 7'},
{id:8,name: 'user 8'},
{id:9,name: 'user 9'},
{id:10,name: 'user 10'},
{id:11,name: 'user 11'},
{id:12,name: 'user 12'},
{id:13,name: 'user 13'}
]
// 2nd user
const posts = [
    {id:1,name: 'Post 1'},
    {id:2,name: 'Post 2'},
    {id:3,name: 'Post 3'},
    {id:4,name: 'Post 4'},
    {id:5,name: 'Post 5'},
    {id:6,name: 'Post 6'},
    {id:7,name: 'Post 7'},
    {id:8,name: 'Post 8'},
    {id:9,name: 'Post 9'},
    {id:10,name: 'Post 10'},
    {id:11,name: 'Post 11'},
    {id:12,name: 'Post 12'},
    {id:13,name: 'Post 13'}
    ]
app.get('/posts',paginatedResults(posts),(req,res)=>{
    res.json(res.paginatedResults)

}) 
// getting a list of user
app.get('/users',paginatedResults(users),(req,res)=>{
    // send paginated result
    res.json(res.paginatedResults)
})
// function for paginated result
function paginatedResults(model){
    // middle ware function take req, res and next
    return(req,res,next)=>{
        const page = parseInt(req.query.page)
        const limit = parseInt(req.query.limit)
        // return users between startindex and endindex
        const startIndex = (page-1)*limit
        const endIndex = page*limit
        //append results
        const results = {}
        if(endIndex<model.length){
            // result object
            results.next = {
                page:page+1,//next page
                limit:limit
            }
    
        }
         
        // checking previous page =0
        if(startIndex>0){
            results.previous = {
                page:page-1,//next page
                limit:limit
            }  
        }   
        results.results=model.slice(startIndex,endIndex)
        res.paginatedResults = results
        next()
    }
}
// application is listening at port 3000
app.listen(3000)
